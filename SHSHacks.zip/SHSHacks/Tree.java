
/**
 * Write a description of class Tree here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Tree
{
    private String name;
    private String type;
    private int lifespan;
    private String location;
    private boolean alive;
    
    public Tree()
    {
        alive = true;
    }
    public boolean getAlive()
    {
        return alive;
    }
    public void setName(String n)
    {
        name = n;
    }
    public String getName()
    {
        return name;
    }
    public void setType(String t)
    {
        type = t;
    }
    public String getType()
    {
        return type;
    }
    public void setLifeSpan(int l)
    {
        lifespan = l;
    }
    public String getLifeSpan()
    {
        return name;
    }
    public void setLocation(String lo)
    {
        location = lo;
    }
    public String getLocation()
    {
        return location;
    } 
    public void die()
    {
        alive = false;
    }
}
