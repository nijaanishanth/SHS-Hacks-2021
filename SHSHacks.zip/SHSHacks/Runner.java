
/**
 * Write a description of class Runner here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
import java.applet.*;
public class Runner extends Applet
{
    public static void main(String[] args)
    {
        Tree tr = new Tree();
        int q = 1;
        while(q > 0)
        {
            System.out.println("Hello! Welcome to Tree Savers!\nYour Goal is To Keep Your Tree Alive!\nType ENTER to Start");
            Scanner sc = new Scanner(System.in);
            String name = sc.nextLine();
            System.out.println("Tell Us Your Tree's Name: ");
            name = sc.nextLine();
            tr.setName(name);
            System.out.println("Select a tree type (Enter the Number):\n1. The Florida Yew\n2. The Giant Sequoia\n3. The Monkey Puzzle Tree\n4. The Baobab Tree\n5. Bois Dentelle");
            int type = sc.nextInt();
            if(type == 1)
            {
                tr.setType("The Florida Yew");
                tr.setLocation("Florida");
                System.out.println("Tree Selected: The Florida Yew\n");
                System.out.println("The Florida Yew is a small tree native in Florida that grows up to 20 feet and can live more than 1000 years, \nIt produces Taxol, which is an anticancer drug. and is not collected anymore for commercial uses because it is very rare. \nDue to its slow growth, high demand for leaves and many other common factors such as illegal logging and forest fires, it became endangered.");
                System.out.println("You hear of a new type of tree called the Florida Yew, where are you most likely to find one?");
                System.out.println("1. The University of Florida Herbarium\n2. A Miami Beach\n3. Torreya State Park \n4. A local tavern");
                int op = sc.nextInt();
                if(op == 2 || op == 4)
                {
                    System.out.println("Your Tree Has Died :(\nflorida yews are rarely found outside of supervised parks or herbariums, which is why we should protect them!");
                    tr.die();
                }
                else
                {
                    System.out.println("Yes! florida yews are rarely found outside of supervised parks or herbariums, which is why we should protect them!");
                    System.out.println("Click ENTER to continue");
                    Scanner sca = new Scanner(System.in);
                    String r = sca.nextLine();
                    System.out.println("\nWhen you see " + name + " for the first time, you think it is similar to a(n)...");
                    System.out.println("1. willow tree\n2. cherry blossom tree\n3. pine tree\n4. oak tree");
                    op = sc.nextInt();
                    if(op == 1 || op == 2 || op == 4)
                    {
                        System.out.println("Your Tree Has Died :(\n" + name + " tree is offended! florida yews are from the same family as pine trees");
                        tr.die();
                    }
                    else
                    {
                        System.out.println("Yes!  florida yews are from the same family as pine trees");
                        System.out.println("Click ENTER to continue");
                        r = sca.nextLine();
                    }
                }
                
            }
            if(type == 2)
            {
                tr.setType("The Giant Sequoia");
                tr.setLocation("Northern California, Oregon, Washington");
                tr.setLifeSpan(3000);
                System.out.println("Tree Selected: The Giant Sequoia");
                System.out.println("The Great Sequoia is an enormous tree that can grow up to be around 30 feet in diameter and 250 feet high! \nThese trees live for almost 3000 years, being number 1 on the list of top 10 oldest trees in America! \nCommonly located in the North-west area of the United States, it became endangered from droughts,lack of precipitation and  fire suppression.");
                System.out.println("\nYou come across a Giant Sequoia and notice some brown foliage towards the top. What does it need? (Enter a number)");
                System.out.println("1. A Lullaby\n2. Water\n3. A WildFire\n4. Nutrients");
                int op = sc.nextInt();
                if(op == 1 || op == 3 || op == 4)
                {
                    System.out.println("Your Tree Has Died :(\nwhen giant sequioas are dehydrated, brown foliage appears at the top of the tree");
                    tr.die();
                }
                else
                {
                    System.out.println("Yes! when giant sequioas are dehydrated, brown foliage appears at the top of the tree");
                    System.out.println("Click ENTER to continue");
                    Scanner sca = new Scanner(System.in);
                    String r = sca.nextLine();
                    System.out.println("\nWhen taking a walk, you see the beginnings of a fire at the base of a Giant Sequoia, what do you do?");
                    System.out.println("1. Try to put it out with water\n2. Call for a firefighter\n3. Run\n4. Stay by the scene to make sure the tree doesn't get hurt");
                    op = sc.nextInt();
                    if(op == 1 || op == 2 || op == 4)
                    {
                        System.out.println("Your Tree Has Died :(\ngiant sequoias thrive off wildfires, fire suppression kills them");
                        tr.die();
                    }
                    else
                    {
                        System.out.println("Yes! giant sequoias thrive off wildfires, fire suppression kills them");
                        System.out.println("Click ENTER to continue");
                        r = sca.nextLine();
                    }
                }
            }
            if(type == 3)
            {
                tr.setType("The Monkey Puzzle Tree");
                tr.setLocation("Andes Mountains, South America");
                tr.setLifeSpan(700);
                System.out.println("Tree Selected: The Monkey Puzzle Tree");
                System.out.println("A timber conifer and an evergreen ornamental that grows up to 50 meters, gets its name from the arrangement of their needle-pointed leaves. \tThe Monkey puzzle tree was declared as a monument in Chile in 1976 to protect, but it is still considered endangered because there has been illegal felling activity and habitat fragmentation in its habitat.");
                System.out.println("\nWhen was " + name + "'s Species declared as a natural monument?");
                System.out.println("1. 1988\n2. 1976\n3. 1990\n4. 1968");
                int op = sc.nextInt();
                if(op == 1 || op == 3 || op == 4)
                {
                    System.out.println("Your Tree Has Died :(\nthe monkey puzzle was declared a natural monument in 1976 by Chile to be protected by logging, but that didn't stop it from still being endangered");
                    tr.die();
                }
                else
                {
                    System.out.println("Yes! the monkey puzzle was declared a natural monument in 1976 by Chile to be protected by logging, but that didn't stop it from still being endangered!");
                    System.out.println("Click ENTER to continue");
                    Scanner sca = new Scanner(System.in);
                    String r = sca.nextLine();
                    System.out.println("You see some suspicious people by " + name + " what are they trying to do?");
                    System.out.println("1. Tapping it for sap\n2. Taking its leaves to sell them\n3. Cutting it down\n4. Painting it");
                    op = sc.nextInt();
                    if(op == 1 || op == 2 || op == 4)
                    {
                        System.out.println("Your Tree Has Died :(\nyou failed to protect " + name + "! monkey puzzle trees are endangered due to illegal fellers");
                        tr.die();
                    }
                    else
                    {
                        System.out.println("You protected " + name + "! monkey puzzle trees are endangered due to illegal fellers");
                        System.out.println("Click ENTER to continue");
                        r = sca.nextLine();
                    }
                }
            }
            if(type == 4)
            {
                tr.setType("The Baobab Tree");
                tr.setLocation("Madagascar, Africa, Western Australia");
                System.out.println("Tree Selected: The Baobab Tree");
                System.out.println("Baobabs trees commonly found in Madagascar, throughout Africa and some parts of Asia, usually live for around 1500 years. \nParts of the tree are used in medicines, for shade and the fruits provide many nutrient benefits. \nKnown as the “tree of life”, it is unfortunately dying due to climate changes such as droughts, floods and storms, and many other factors.");
                System.out.println("What grows on the branches of " + name);
                System.out.println("1. flowers\n2. apples\n3. oranges\n4. money");
                int op = sc.nextInt();
                if(op == 2 || op == 3 || op == 4)
                {
                    System.out.println("Your Tree Has Died :(\n" + name + "is offended! flowers on the baobab tree can range from yellow to red to white");
                    tr.die();
                }
                else
                {
                    System.out.println("Yes! , flowers on the baobab tree can range from yellow to red to white, and have 5 petals");
                    System.out.println("Click ENTER to continue");
                    Scanner sca = new Scanner(System.in);
                    String r = sca.nextLine();
                    System.out.println("Why have most Baobab trees died?");
                    System.out.println("1. Tree cutters\n2. Dehydration\n3. Climate Change\n4. Animals");
                    op = sc.nextInt();
                    if(op == 1 || op == 2 || op == 4)
                    {
                        System.out.println("Your Tree Has Died :(\nyou failed to protect " + name + "! 9/13 of the oldest baobab trees have died due to the effects of climate change since 2005,");
                        tr.die();
                    }
                    else
                    {
                        System.out.println("You protected " + name + "! 9/13 of the oldest baobab trees have died due to the effects of climate change since 2005");
                        System.out.println("Click ENTER to continue");
                        r = sca.nextLine();
                    }
                }
            }
            if(type == 5)
            {
                tr.setType("Bois Dentelle");
                tr.setLocation("Mauritius, Singapore");
                System.out.println("Tree Selected: Bois Dentelle");
                System.out.println("Known for its bell-shaped flowers and patterns, these Bois Dentelles are located high on the island of Mauritius. \nThere are only two of them left, which results in the plant to become extinct soon. \nMany try to preserve this tree by growing them in greenhouses, and having seeds taken, but there still remains very few.");
                System.out.println("How many Bois Dentelle are left in the world?");
                System.out.println("1. 5\n2. 3\n3. 10\n4. 2");
                int op = sc.nextInt();
                if(op == 2 || op == 3 || op == 1)
                {
                    System.out.println("Your Tree Has Died :(\nyou just killed off one of the last two bois dentelle in the world!");
                    tr.die();
                }
                else
                {
                    String sp = sc.nextLine();
                    System.out.println("Yes! , there are only 2 bois dentelle left in the world, so we must protect them!");
                    System.out.println("Click ENTER to continue");
                    Scanner sca = new Scanner(System.in);
                    String r = sca.nextLine();
                    System.out.println("Why is this tree so close to extinction?");
                    System.out.println("1. Tree cutters\n2. Dehydration\n3. Climate Change\n4. Other Trees Invading");
                    op = sc.nextInt();
                    if(op == 1 || op == 2 || op == 3)
                    {
                        System.out.println("Your Tree Has Died :(\nyou failed to protect " + name + "the environment bois dentelle lives in has been overrun by other, more commercially beneficial trees");
                        tr.die();
                    }
                    else
                    {
                        System.out.println("You protected " + name + "! the environment bois dentelle lives in has been overrun by other, more commercially beneficial trees");
                        System.out.println("Click ENTER to continue");
                        r = sca.nextLine();
                    }
                }
            }
            System.out.println("Your Tree: " + tr.getType() + "\nName: " + tr.getName());
            if(tr.getAlive() == true)
            {
                System.out.println("Status: alive");
                System.out.println("Congrats on keeping your rare species alive! Now go do the same in your community with your knowledge!");
            }
            else
            {
                System.out.println("Status: dead");
                System.out.println("Better Luck Next Time! Remember, you can still save the trees in your community!");
            }
            System.out.println("Would you like to play again? (y/n)");
            Scanner scan = new Scanner(System.in);
            String again = scan.nextLine();
            System.out.println("");
            if(again.equals("n"))
            {
                q = 0;
            }
        }
        System.out.println("Thank you for playing!");
    }
}
